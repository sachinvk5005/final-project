﻿<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colorlib Templates">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="Colorlib Templates">
    <!-- <meta name="csrf-token" content="{{ csrf_token() }}"> -->
    <!-- Title Page-->
    <title>Register</title>

    <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
     <link href="vendor/css/main.css" rel="stylesheet" media="all">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <!-- <script src="js/jquery-2.1.0.min.js"></script> -->
    <script
  src="https://code.jquery.com/jquery-2.2.4.min.js"
  integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44="
  crossorigin="anonymous"></script> 
   <!-- Jquery JS-->
   <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="vendor/js/global.js"></script>
 <script src="{{ asset('js/validate/jquery.js') }}"></script>
    <script src="{{ asset('js/validate/bootstrap.min.js') }}"></script>
    <script src="{{ asset('js/validate/jquery.validate.min.js') }}"></script>
    <script src="{{ asset('js/validate/additional-methods.min.js') }}"></script>
	<script src="js/validation.js"></script>
   

   
    <meta name="csrf-token" content="{{ csrf_token() }}">
    
	 
    
</head>

<body>
    <div class="page-wrapper bg-gra-03 p-t-45 p-b-50">
        <div class="wrapper wrapper--w790">
            <div class="card card-5">
                <div class="card-heading">
                    <h2 class="title">Sign up</h2>
                </div>
                <div class="card-body">
                <form action="registrations" method="post" id="signup-form">
				@csrf
				@if (count($errors) > 0)
                        <div class="alert alert-danger">
                             <ul>
                                <!-- Enter E-Mail And Password ! -->
                                 @foreach ($errors->all() as $error)
                                 <li>{{ $error }}</li>
                                  @endforeach
                            </ul>
                        </div> 
                        @endif

                    
                        <!-- <div class="form-row m-b-55">
                            <div class="name">Name</div>
                            <div class="value">
                                <div class="row row-space">
                                    <div class="col-2">
                                        <div class="input-group-desc">
                                            <input class="input--style-5" type="text" id="fn" name="fname">
                                            <label class="label--desc">first name</label>
                                            <div id=p1></div>
                                        </div>
                                    </div>
                                    <div class="col-2">
                                        <div class="input-group-desc">
                                            <input class="input--style-5" type="text" id="ln" name="lname">
                                            <label class="label--desc">last name</label>
                                            <div id=p2></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> -->
                        <div class="form-row">
                            <div class="name">FirstName</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="text" id="fn" name="fname">
                                    <div id=p4></div>
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">LastName</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="text" id="ln" name="lname">
                                    <div id=p4></div>
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Address</div>
                            <div class="value">
                                <div class="input-group">
                                <textarea name="address" id="txt" class="input--style-5" required></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Phone number</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="text" id="ph" name="phoneno">
                                    <div id=p4></div>
                                </div>
                            </div>
                        </div>
                        <div class="form-row m-b-55">
                            <div class="name">Email</div>
                            <div class="value">
                                <div class="rgggow row-hyrefine">

                                    <div class="coggl-9">
                                        <div class="input-group">
                                            <input class="input--style-5" type="text" id="eml" name="email">
                                            
                                            <div id=p3></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Select Member</div>
                            <div class="valuhhhe">
                                <div class="input-grouggggp">
                                    <div class="rs-selehgvct2 js-selgggect-simple hhselect--no-search">
                                        <select  style="width:500px" id="membertype" name="membertype" class="input--style-5">
                                            <option disabled="disabled" selected="selected">Choose option</option>
                                            <option>User</option>
                                            <option>Mechanic</option>
                                            <option></option>
                                        </select>
                                        <div class="select-dropdown"></div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <!-- <script>

function getComboA(selectObject) {
    var value = selectObject.value;  
    //alert(value);

    if("Mechanic"==value)$("#file").show();else $("#file").hide();


}



                        </script> -->
                         
<!-- <input type="file" name="file" id="file" style="display:none;s"> -->

                        <div class="form-row">
                            <div class="name">Select District</div>
                            <div class="value">
                                <div class="input-group">
                                    <div class="rs-select2 js-select-simple select--no-search">
                                        <select style="width:500px" name="district" id="district" class="input--style-5">
                                            <option disabled="disabled" selected="selected">-- Select District --</option>
                                            <!-- <option value="0">-- Select District -- </option> -->
                                            @isset($district)
			
					                        @foreach($district as $district1)
                                            <option value="{{$district1->d_id}}">{{$district1->dname}}</option>  
					@endforeach
 
					@endisset
                                            
                                        </select>
                                        <div class="select-dropdown"></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="name">Select City</div>
                            <div class="value">
                                <div class="input-group">
                                    <div class="rs-select2 js-select-simple select--no-search">
                                    <select class="input--style-5" style="width:500px" name="city" id="city">
					<option disabled selected value> -- Select city -- </option>
					</select>
                                        <div class="select-dropdown"></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="name">Select Gender</div>
                            <div class="value">
                                <div class="input-group">
                                    <div class="rs-select2 js-select-simple select--no-search">
                                    <select style="width:500px" name="gender">
                                            <option disabled="disabled" selected="selected">Choose option</option>
                                            <option>Male</option>
                                            <option>Female</option>
                                            <option>Other</option>
                                        </select>
                                        <div class="select-dropdown"></div>
                                    </div>
                                </div>
                            </div>
                        </div>


















                        


                        <div class="form-row">
                            <div class="name">Password</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="password" id="pss" name="password">
                                    <div id=p4></div>
                                </div>
                            </div>
                        </div>











                            <div>
                            <button class="btn btn--radius-2 btn--red" type="submit">Register</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="js/ajaxx.js"></script>
 
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->

</html>
<!-- end document-->