<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Breakdown Assistance</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="../../../vendors/iconfonts/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="../../../vendors/css/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- inject:css -->
  <link rel="stylesheet" href="../../../css/style4.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="../../../images/favicon.png" />
  <meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<title></title>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">

	<!-- Bootstrap -->
	<!-- <link type="text/css" rel="stylesheet" href="css/bootstrap11.min.css" />

	Custom stlylesheet -->
	<!-- <link type="text/css" rel="stylesheet" href="css/main1.css" /> -->
    <link rel="stylesheet" type="text/css" href="css/util1.css">
	<link rel="stylesheet" type="text/css" href="css/main1.css">


</head>
<body id="booking">
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
      <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
        <a class="navbar-brand brand-logo" href="index.html"><img src="../../../images/logo.svg" alt="logo"/></a>
        <a class="navbar-brand brand-logo-mini" href="index.html"><img src="../../../images/logo-mini.svg" alt="logo"/></a>
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-stretch">
        <div class="search-field d-none d-md-block">
          <form class="d-flex align-items-center h-100" action="#">
            <!-- <div class="input-group">
              <div class="input-group-prepend bg-transparent">
                  <i class="input-group-text border-0 mdi mdi-magnify"></i>                
              </div>
              <input type="text" class="form-control bg-transparent border-0" placeholder="Search projects">
            </div> -->
          </form>
        </div>
        <ul class="navbar-nav navbar-nav-right">
          <li class="nav-item nav-profile dropdown">
            <a class="nav-link dropdown-toggle" id="profileDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
              <div class="nav-profile-img">
                <img src="../../../images/faces/face1.jpg" alt="image">
                <span class="availability-status online"></span>             
              </div>
              <div class="nav-profile-text">
                <p class="mb-1 text-black">
                <?php
                use App\Regmodel;
                $sess = session()->get('email');
                $a = Regmodel::where('email',$sess)->get();
                foreach ($a as $object)
                    {
                        
                        echo 'Hi ' . $name = $object->fname;
                    }
                ?>
                
                </p>
              </div>
            </a>
            <div class="dropdown-menu navbar-dropdown" aria-labelledby="profileDropdown">
              <!-- <a class="dropdown-item" href="#">
                <i class="mdi mdi-cached mr-2 text-success"></i>
                Activity Log
              </a> -->
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="/login">
                <i class="mdi mdi-logout mr-2 text-primary"></i>
                Signout
              </a>
            </div>
          </li>
          <li class="nav-item d-none d-lg-block full-screen-link">
            <a class="nav-link">
              <i class="mdi mdi-fullscreen" id="fullscreen-button"></i>
            </a>
          </li>
          <!-- <li class="nav-item dropdown">
            <a class="nav-link count-indicator dropdown-toggle" id="messageDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
              <i class="mdi mdi-email-outline"></i>
              <span class="count-symbol bg-warning"></span>
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="messageDropdown">
              <h6 class="p-3 mb-0">Messages</h6>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                    <img src="../../../images/faces/face4.jpg" alt="image" class="profile-pic">
                </div>
                <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                  <h6 class="preview-subject ellipsis mb-1 font-weight-normal">Mark send you a message</h6>
                  <p class="text-gray mb-0">
                    1 Minutes ago
                  </p>
                </div>
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                    <img src="../../../images/faces/face2.jpg" alt="image" class="profile-pic">
                </div>
                <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                  <h6 class="preview-subject ellipsis mb-1 font-weight-normal">Cregh send you a message</h6>
                  <p class="text-gray mb-0">
                    15 Minutes ago
                  </p>
                </div>
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                    <img src="../../../images/faces/face3.jpg" alt="image" class="profile-pic">
                </div>
                <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                  <h6 class="preview-subject ellipsis mb-1 font-weight-normal">Profile picture updated</h6>
                  <p class="text-gray mb-0">
                    18 Minutes ago
                  </p>
                </div>
              </a>
              <div class="dropdown-divider"></div>
              <h6 class="p-3 mb-0 text-center">4 new messages</h6>
            </div>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link count-indicator dropdown-toggle" id="notificationDropdown" href="#" data-toggle="dropdown">
              <i class="mdi mdi-bell-outline"></i>
              <span class="count-symbol bg-danger"></span>
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="notificationDropdown">
              <h6 class="p-3 mb-0">Notifications</h6>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-success">
                    <i class="mdi mdi-calendar"></i>
                  </div>
                </div>
                <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                  <h6 class="preview-subject font-weight-normal mb-1">Event today</h6>
                  <p class="text-gray ellipsis mb-0">
                    Just a reminder that you have an event today
                  </p>
                </div>
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-warning">
                    <i class="mdi mdi-settings"></i>
                  </div>
                </div>
                <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                  <h6 class="preview-subject font-weight-normal mb-1">Settings</h6>
                  <p class="text-gray ellipsis mb-0">
                    Update dashboard
                  </p>
                </div>
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-info">
                    <i class="mdi mdi-link-variant"></i>
                  </div>
                </div>
                <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                  <h6 class="preview-subject font-weight-normal mb-1">Launch Admin</h6>
                  <p class="text-gray ellipsis mb-0">
                    New admin wow!
                  </p>
                </div>
              </a>
              <div class="dropdown-divider"></div>
              <h6 class="p-3 mb-0 text-center">See all notifications</h6>
            </div>
          </li>
          <li class="nav-item nav-logout d-none d-lg-block">
            <a class="nav-link" href="#">
              <i class="mdi mdi-power"></i>
            </a>
          </li> -->
          <li class="nav-item nav-settings d-none d-lg-block">
            <a class="nav-link" href="#">
              <i class="mdi mdi-format-line-spacing"></i>
            </a>
          </li>
        </ul>
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="mdi mdi-menu"></span>
        </button>
      </div>
    </nav>
    <!-- partial -->
    
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          <li class="nav-item nav-profile">
            <a href="#" class="nav-link">
              <div class="nav-profile-image">
                <img src="../../../images/faces/face1.jpg" alt="profile">
                <span class="login-status online"></span> <!--change to offline or busy as needed-->              
              </div>
              <div class="nav-profile-text d-flex flex-column">
                <span class="font-weight-bold mb-2"><?php echo '' . $name = $object->fname;?></span>
                <span class="text-secondary text-small">user</span>
              </div>
              <i class="mdi mdi-bookmark-check text-success nav-profile-badge"></i>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="search">
              <span class="menu-title">Search mechanics</span>
              <!-- <i class="mdi mdi-home menu-icon"></i> -->
            </a>
          </li>
          
          <li class="nav-item">
          
            <a class="nav-link" href="msg">
              <span class="menu-title">Notifications</span>
              <!-- <i class="mdi mdi-contacts menu-icon"></i> -->
            </a>
          </li>
          <li class="nav-item">
          
            <a class="nav-link" href="../cancel">
              <span class="menu-title">Cancel booking</span>
              <!-- <i class="mdi mdi-format-list-bulleted menu-icon"></i> -->
            </a>
          </li>
          
         
          
          
        </ul>
      </nav>
      <?php
         $id=1;                               
                                        $sess=session()->get('id');
                                        $ab=Regmodel::where('id',$sess)->where('membertype','Mechanic')->get();
                                        
                                        foreach($ab as $object)
                                        {
                                            //$log_id=$object->id;
                                            $id=$object->id;
                                        }
                                      
                                        $v = DB::table('regmodels')->where('id',$id)->first();
                                       
                                         
                                       ?>

      <div id="booking" class="section">
		<div class="section-center">
			<div class="container">
				<div class="row">
					<div class="booking-form">
						<div class="form-header">
							<h1>Book Mechanic</h1>
						</div>
						<form action="{{route('boook')}}" method="post">
            @csrf
							<div class="row">
								<div class="col-sm-6">
									<div class="form-group">
										<span class="form-label">Firstname</span>
										<input class="form-control" name="t1" type="text" disabled value=<?php echo $v->fname;?>>
									</div>
								</div>
								<div class="col-sm-6">
									<div class="form-group">
										<span class="form-label">Lastname</span>
										<input class="form-control" name="t2" type="text" disabled value=<?php echo $v->lname;?>>
									</div>
								</div>
							</div>
							<div class="form-group">
								<span class="form-label">Address</span>
								<input class="form-control" name="t3" type="text" disabled value=<?php echo $v->address;?>>
							</div>
							<div class="form-group">
								<span class="form-label">Email</span>
								<input class="form-control" name="t4" type="text" disabled value=<?php echo $v->email;?>>
							</div>
							<div class="form-group">
								<span class="form-label">Contact Number</span>
								<input class="form-control" name="t5" type="text" disabled  value=<?php echo $v->phoneno;?>>
                
                <input type="hidden" name="id" value={{$v->id}}>
                <input type="hidden" name="uid" value=<?php $ss=session()->get('id');?>>
							</div>
                  
                   
                   
<!-- //<form action="{{route('redirect')}}" method="post">  -->
@csrf                                             
               <?php
                $s = session()->get('email');
                $sa=Regmodel::where('email',$s)->get();
                $user= $sa[0]->id;
                $ab=DB::select("select * from book where uid=$user and mid=$id");
                
        if($ab)
        {


          // $ab2=DB::select("select B.*,T.* from book B,time T where B.uid=$user and B.mid=$id 
          //                   AND T.tid=B.time");

          //        foreach($ab2 as $g)
          //        {
          //         echo '<table>
          //         <tr>
                  
          //         <td>'.$g->fhh.'</td>
          //         <td>'.$g->ftime.'<td>
          //         <td>'.$g->thh.'<td>
          //         <td>'.$g->totime.'<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          //         <td><button class="btn btn-block btn-lg btn-gradient-primary mt-4">Cancel</button><td>
          //         <input type="text" id="t" name="text" value="'.$g->bookid.'" >
          //         </tr>
          //         </table>';
          //         }
                 



           echo" you already booked an appointment";


        }
        else
        {
          echo ' <div class="form-group">
								<span class="form-label">Complaint</span>
								<textarea class="form-control" name="t6" placeholder="Enter complaint of vehicle"></textarea>

                 

							 </div>';
          
           echo '<div class="row">
								<div class="col-sm-5">
									<div class="form-group">
										<span class="form-label">Todays Availible Hours</span>
                    <!-- <input class="form-control" name="t7" type="date" required> -->';
                    
                    foreach($val as $times)
                    {








                    echo '<table>
                    <tr>
                    <td><input type="radio" name="radio" value="'.$times->tid.'"></td>
                    <td>'.$times->fhh.'</td>

                    </tr>
                    </table>';
                    }
                echo'	</div>
                <div class="form-btn">
								<button class="btn btn-block btn-lg btn-gradient-primary mt-4">Book Now</button>
							</div>
								</div> ';
							
        }
        ?>
<!-- </form> -->
							 	<!-- <div class="col-sm-7">
									<div class="row">
										<div class="col-sm-4">
											<div class="form-group">
												<span class="form-label">Hour</span>
												<select class="form-control" name="t8">
													<option>1</option>
													<option>2</option>
													<option>3</option>
													<option>4</option>
													<option>5</option>
													<option>6</option>
													<option>7</option>
													<option>8</option>
													<option>9</option>
													<option>10</option>
													<option>11</option>
													<option>12</option>
												</select>
												<span class="select-arrow"></span>
											</div>
										</div>
										<div class="col-sm-4">
											<div class="form-group">
												<span class="form-label">Min</span>
												<select class="form-control" name="t9">
													<option>05</option>
													<option>10</option>
													<option>15</option>
													<option>20</option>
													<option>25</option>
													<option>30</option>
													<option>35</option>
													<option>40</option>
													<option>45</option>
													<option>50</option>
													<option>55</option>
												</select>
												<span class="select-arrow"></span>
											</div>
										</div>
										<div class="col-sm-4">
											<div class="form-group">
												<span class="form-label">AM/PM</span>
												<select class="form-control" name="t10">
													<option>AM</option>
													<option>PM</option>
												</select>
												<span class="select-arrow"></span>
											</div>
										</div>
									</div>
								</div> -->
                

							</div> 
							
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>

      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="../../../vendors/js/vendor.bundle.base.js"></script>
  <script src="../../../vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="../../../js/off-canvas.js"></script>
  <script src="../../../js/misc.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="../../../js/dashboard.js"></script>
  <!-- End custom js for this page-->
  <!-- <script>
  $(document).ready(function(){
  $('#t1').css('display', 'none'); 
  });

  </script>
  <script>
function buttn()
{  $('#t1').css('display', 'block'); 
} -->

  
  </script>
</body>

</html>
